package sample;

public class Constr {
	private int x;

	       private Constr(){
	       System.out.println("Constructor is called");
	       x = 25;
	       }
	      
	       public static void main(String[] args){
	    		   Constr obj = new Constr();
	    		   System.out.println("Value of x = " + obj.x);
	    		  
	    	   }
	       }

/*Constructor is called
Value of x = 25*/