package sample;
import java.util.Scanner;

public class com2strings {
	public static void stringcom(String s1, String s2){
		int same = 0;
		int l1= s1.length();
		int l2=s2.length();
		int min=0;
		if (l1>l2)
			min=l2;
		else
			min=l1;
		for(int i=0;i<min;i++){
			int str1=(int)s1.charAt(i);
			int str2=(int)s2.charAt(i);
			if(str1!=str2)
				same = 1;
			else 
				 same = 0;
			}
		if (same==1)
			System.out.println("Strings are different");
		else 
			System.out.println("String are same");
	}
	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter 1st string");
		String str1 = sc.nextLine();
		System.out.println("enter 2nd string");
		String str2= sc.nextLine();
		stringcom(str1,str2);
	}
}
/*enter 1st string
helo
enter 2nd string
helo
String are same

enter 1st string
jey
enter 2nd string
helo
Strings are different*/

	
