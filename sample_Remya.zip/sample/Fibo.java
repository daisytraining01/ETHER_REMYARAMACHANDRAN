package sample;
import java.util.Scanner;

public class Fibo {
	public static void main(String[] args) {
		
		Scanner scan=new Scanner(System.in); 
        int x = 0, y = 1;
        System.out.print("Enter how many numbers in Fibonacci series to be displayed");
        int num=scan.nextInt();

        for (int i = 1; i <= num; i++)
        {
            System.out.print(x + " ");
            int sum = x + y;
            x = y;
            y = sum;
        }
    }

}
/*Enter how many numbers in Fibonacci series to be displayed
14
0 1 1 2 3 5 8 13 21 34 55 89 144 233 */
